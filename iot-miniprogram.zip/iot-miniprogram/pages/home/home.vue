<template>
	<view class="home-container">
		<!-- 未登录状态：手机号登录表单 -->
		<view class="login-box" v-if="!isLogin">
			<!-- 顶部标题+Icon预留位置 -->
			<view class="login-header">
				<view class="icon-wrapper">
					<!-- 预留Icon位置：可替换为<image>或字体图标 -->
					<text class="icon-placeholder"></text>
				</view>
				<view class="login-title">手机号快捷登录</view>
			</view>

			<view class="input-wrapper">
				<!-- 手机号Icon预留位置 -->
				<view class="input-icon">
					<text class="icon-phone"></text>
				</view>
				<input v-model="phone" type="number" placeholder="请输入手机号" class="phone-input" maxlength="11" />
			</view>

			<button class="login-btn" @click="handleLogin" :disabled="!isPhoneValid">
				登录
			</button>

			<!-- 其他登录方式（预留Icon位置） -->
			<view class="other-login">
				<text class="other-login-text">其他登录方式</text>
				<view class="icon-group">
					<view class="icon-item">
						<text class="icon-wechat"></text>
					</view>
					<view class="icon-item">
						<text class="icon-qq"></text>
					</view>
				</view>
			</view>
		</view>

		<!-- 已登录状态：用户信息展示 -->
		<view class="user-info-box" v-else>
			<!-- 头像区域（带编辑Icon预留） -->
			<view class="avatar-wrapper">
				<image class="avatar" src="/static/avatar.jpg" mode="aspectFill"></image>
				<view class="edit-icon">
					<!-- 编辑Icon预留位置 -->
					<text class="icon-edit"></text>
				</view>
			</view>

			<!-- 用户信息 -->
			<view class="user-info-content">
				<view class="username">{{ userInfo.username || '未设置昵称' }}</view>
				<view class="phone">{{ userInfo.phone }}</view>
			</view>

			<!-- 功能按钮区（带Icon预留） -->
			<view class="user-function">
				<view class="function-item">
					<text class="icon-function icon-message"></text>
					<text class="function-text">消息</text>
				</view>
				<view class="function-item">
					<text class="icon-function icon-setting"></text>
					<text class="function-text">设置</text>
				</view>
				<view class="function-item">
					<text class="icon-function icon-logout"></text>
					<text class="function-text" @click="handleLogout">退出</text>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import {
		userApi
	} from '@/common/api/user.js';
	import {
		initWebSocket
	} from '@/common/utils/websocket.js';

	export default {
		data() {
			return {
				phone: '', // 手机号输入值
				isLogin: false, // 是否登录标识
				userInfo: {} // 用户信息（userId/phone/username）
			};
		},
		computed: {
			// 手机号格式验证（11位数字）
			isPhoneValid() {
				return /^1[3-9]\d{9}$/.test(this.phone);
			}
		},
		onShow() {
			// 页面显示时检查缓存，恢复登录状态
			this.checkLoginStatus();
		},
		methods: {
			// 检查登录状态（读取缓存）
			checkLoginStatus() {
				const token = uni.getStorageSync('token');
				const userInfo = uni.getStorageSync('userInfo');
				if (token && userInfo) {
					this.isLogin = true;
					this.userInfo = userInfo;
					// 已有登录状态时，确保 WebSocket 建立
					initWebSocket();
				}
			},

			// 登录逻辑
			async handleLogin() {
				try {
					// 调用登录接口
					const res = await userApi.login({
						phone: this.phone
					});
					if (res.code === 200) {
						const {
							userId,
							token,
							phone,
							username
						} = res.data;

						// 存储token和用户信息
						uni.setStorageSync('token', token);
						uni.setStorageSync('userInfo', {
							userId,
							phone,
							username
						});

						// 更新页面状态
						this.isLogin = true;
						this.userInfo = {
							userId,
							phone,
							username
						};

						// 登录成功后自动建立 WebSocket 连接
						initWebSocket();

						uni.showToast({
							title: '登录成功',
							icon: 'success'
						});
					}
				} catch (err) {
					console.error('登录失败：', err);
					uni.showToast({
						title: '登录失败，请重试',
						icon: 'none'
					});
				}
			},

			// 新增退出登录方法（配套已登录状态UI）
			handleLogout() {
				uni.showModal({
					title: '提示',
					content: '确定要退出登录吗？',
					success: (res) => {
						if (res.confirm) {
							// 清除缓存
							uni.removeStorageSync('token');
							uni.removeStorageSync('userInfo');
							// 重置状态
							this.isLogin = false;
							this.userInfo = {};
							this.phone = '';
							uni.showToast({
								title: '已退出登录',
								icon: 'success'
							});
						}
					}
				});
			}
		}
	};
</script>

<style scoped>
	/* 页面容器：整体居中 */
	.home-container {
		width: 100%;
		min-height: 100vh;
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
		background-color: #f5f7fa;
		padding: 0 40rpx;
		box-sizing: border-box;
	}

	/* ---------------- 登录状态样式 ---------------- */
	.login-box {
		width: 100%;
		max-width: 600rpx;
		display: flex;
		flex-direction: column;
		gap: 40rpx;
		background-color: #ffffff;
		padding: 60rpx 50rpx;
		border-radius: 16rpx;
		box-sizing: border-box;
		box-shadow: 0 2rpx 20rpx rgba(0, 0, 0, 0.03);
	}

	/* 登录头部 */
	.login-header {
		display: flex;
		flex-direction: column;
		align-items: center;
		gap: 20rpx;
		margin-bottom: 10rpx;
	}

	.icon-wrapper {
		width: 100rpx;
		height: 100rpx;
		border-radius: 50%;
		background-color: #e8f4ff;
		display: flex;
		justify-content: center;
		align-items: center;
	}

	/* Icon占位符：可替换为实际Icon */
	.icon-placeholder {
		display: inline-block;
		width: 50rpx;
		height: 50rpx;
		background-color: #007aff;
		border-radius: 8rpx;
	}

	.login-title {
		font-size: 36rpx;
		font-weight: 600;
		color: #1d2129;
	}

	/* 手机号输入框 */
	.input-wrapper {
		display: flex;
		align-items: center;
		border: 1px solid #e5e6eb;
		border-radius: 12rpx;
		padding: 0 24rpx;
		background-color: #fafafa;
		transition: border-color 0.3s;
	}

	.input-wrapper:focus-within {
		border-color: #007aff;
	}

	.input-icon {
		width: 40rpx;
		height: 40rpx;
		margin-right: 16rpx;
		display: flex;
		justify-content: center;
		align-items: center;
	}

	.icon-phone {
		display: inline-block;
		width: 24rpx;
		height: 24rpx;
		background-color: #86909c;
		border-radius: 4rpx;
	}

	.phone-input {
		font-size: 32rpx;
		color: #1d2129;
		width: 100%;
		height: 88rpx;
		background-color: transparent;
	}

	.phone-input::placeholder {
		color: #86909c;
	}

	/* 登录按钮 */
	.login-btn {
		background-color: #007aff;
		color: #ffffff;
		border: none;
		border-radius: 12rpx;
		padding: 10rpx 40rpx;
		font-size: 34rpx;
		font-weight: 500;
		transition: background-color 0.3s;
	}

	.login-btn:disabled {
		background-color: #c9d8e8;
		color: #ffffff;
	}

	/* 其他登录方式 */
	.other-login {
		display: flex;
		flex-direction: column;
		align-items: center;
		gap: 20rpx;
		margin-top: 10rpx;
	}

	.other-login-text {
		font-size: 28rpx;
		color: #86909c;
	}

	.icon-group {
		display: flex;
		gap: 40rpx;
	}

	.icon-item {
		width: 80rpx;
		height: 80rpx;
		border-radius: 50%;
		background-color: #fafafa;
		display: flex;
		justify-content: center;
		align-items: center;
	}

	.icon-wechat {
		display: inline-block;
		width: 40rpx;
		height: 40rpx;
		background-color: #07c160;
		border-radius: 8rpx;
	}

	.icon-qq {
		display: inline-block;
		width: 40rpx;
		height: 40rpx;
		background-color: #12b7f5;
		border-radius: 8rpx;
	}

	/* ---------------- 已登录状态样式 ---------------- */
	.user-info-box {
		width: 100%;
		max-width: 600rpx;
		display: flex;
		flex-direction: column;
		align-items: center;
		gap: 50rpx;
		background-color: #ffffff;
		padding: 80rpx 60rpx;
		border-radius: 16rpx;
		box-sizing: border-box;
		box-shadow: 0 2rpx 20rpx rgba(0, 0, 0, 0.03);
	}

	/* 头像区域 */
	.avatar-wrapper {
		position: relative;
	}

	.avatar {
		width: 180rpx;
		height: 180rpx;
		border-radius: 50%;
		border: 6rpx solid #f5f7fa;
	}

	.edit-icon {
		position: absolute;
		right: 10rpx;
		bottom: 10rpx;
		width: 50rpx;
		height: 50rpx;
		border-radius: 50%;
		background-color: #007aff;
		display: flex;
		justify-content: center;
		align-items: center;
	}

	.icon-edit {
		display: inline-block;
		width: 24rpx;
		height: 24rpx;
		background-color: #ffffff;
		border-radius: 2rpx;
	}

	/* 用户信息 */
	.user-info-content {
		display: flex;
		flex-direction: column;
		align-items: center;
		gap: 16rpx;
	}

	.username {
		font-size: 40rpx;
		font-weight: 600;
		color: #1d2129;
	}

	.phone {
		font-size: 28rpx;
		color: #86909c;
	}

	/* 功能按钮区 */
	.user-function {
		display: flex;
		justify-content: space-around;
		width: 100%;
		margin-top: 20rpx;
		padding-top: 30rpx;
		border-top: 1px solid #f0f2f5;
	}

	.function-item {
		display: flex;
		flex-direction: column;
		align-items: center;
		gap: 12rpx;
	}

	.icon-function {
		display: inline-block;
		width: 40rpx;
		height: 40rpx;
		border-radius: 8rpx;
	}

	.icon-message {
		background-color: #e8f4ff;
	}

	.icon-setting {
		background-color: #fdf2e8;
	}

	.icon-logout {
		background-color: #fef0f0;
	}

	.function-text {
		font-size: 26rpx;
		color: #4e5969;
	}
</style>