<template>
	<view class="home-page">
		<!-- 顶部欢迎区域 -->
		<view class="header">
			<view class="welcome-area">
				<view class="welcome-text">欢迎回家，{{ userName }}</view>
				<view class="sub-text">今天室内温度适宜，空气质量良好</view>
			</view>
			<!-- 消息图标 -->
			<view class="message-icon-wrapper" @click="showNextMessage">
				<image class="message-icon" :src="hasUnreadMessage ? '/static/message_red.png' : '/static/message.png'"
					mode="aspectFill"></image>
			</view>
		</view>

		<!-- 我的设备标题 -->
		<view class="section-title">我的设备</view>

		<!-- 设备列表 -->
		<view class="device-list">
			<!-- 智能灯卡片 -->
			<view class="device-card light-card">
				<view class="card-top">
					<view class="avatar-wrapper">
						<image class="avatar-image" src="/static/light.png" mode="aspectFill"></image>
					</view>
					<view class="device-info">
						<view class="device-name-row">
							<text class="device-name">智能灯</text>
						</view>
						<view class="device-status-row">
							<view class="status-dot" :class="lightStatus.online ? 'status-online' : 'status-offline'">
							</view>
							<text class="status-text">
								{{ lightStatus.online ? '已连接' : '未连接' }}
							</text>
						</view>
					</view>
				</view>

				<view class="card-bottom">
					<view class="card-bottom-left">
						<text class="bottom-label">开关</text>
						<switch class="light-switch" :checked="lightOpen" color="#3b82f6" @change="handleLightToggle" />
					</view>
					<view class="card-bottom-right">
						<text class="bottom-desc">亮度 {{ lightStatus.brightness }}%</text>
					</view>
				</view>
			</view>

			<!-- 温湿度感应器卡片 -->
			<view class="device-card sensor-card">
				<view class="card-top">
					<view class="avatar-wrapper">
						<image class="avatar-image" src="/static/sensor.png" mode="aspectFill"></image>
					</view>
					<view class="device-info">
						<view class="device-name-row">
							<text class="device-name">温湿度感应器</text>
						</view>
						<view class="device-status-row">
							<view class="status-dot" :class="sensorData.sensorConnected ? 'status-online' : 'status-offline'"></view>
							<text class="status-text">{{ sensorData.sensorConnected ? '已连接' : '未连接' }}</text>
						</view>
					</view>
				</view>

				<view class="card-bottom sensor-bottom">
					<view class="sensor-main-value">
						<text class="sensor-temperature">
							{{ sensorData.temperature }}℃
						</text>
					</view>
					<view class="sensor-extra">
						<text class="sensor-humidity">湿度 {{ sensorData.humidity }}%</text>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import {
		deviceApi
	} from '@/common/api/device.js';

	export default {
		data() {
			return {
				userInfo: null,
				// 顶部欢迎语用户名
				userName: '小明',
				// 智能灯默认参数
				lightStatus: {
					open: true, // 开关状态：开启/关闭
					online: true, // 联网状态：已联网/未联网
					brightness: 80, // 亮度（0-100）
					temperature: 4500 // 色温（单位：K，常规2700-6500）
				},
				lightOpen: true,
				// 温湿度感应器默认参数
				sensorData: {
					temperature: 25.5, // 温度
					humidity: 60, // 湿度
					sensorConnected: true, // 联网状态
				},
				// 设备列表及按类别拆分后的设备信息
				deviceList: [],
				lightDevice: null,
				sensorDevice: null,
				// 新消息相关数据
				messageQueue: [], // 消息队列（存储未读消息）
				hasUnreadMessage: false // 是否有未读消息（控制图标变红）
			};
		},
		onLoad() {
			// 从缓存恢复用户名
			const userInfo = uni.getStorageSync('userInfo');
			if (userInfo && userInfo.username) {
				this.userInfo = userInfo;
				this.userName = userInfo.username;
			}
			// 调用接口获取用户设备列表
			this.getDeviceData();
		},
		onShow() {
			// 监听全局 WebSocket 消息
			uni.$on('ws-message', this.handleWsMessage);
		},
		onHide() {
			// 页面隐藏/切换 Tab 时移除监听，避免重复绑定
			uni.$off('ws-message', this.handleWsMessage);
		},
		onUnload() {
			uni.$off('ws-message', this.handleWsMessage);
		},
		methods: {
			// 智能灯开关切换
			async handleLightToggle(e) {
				try {
					if (this.lightStatus.online === false) {
						uni.showToast({
							title: '设备已断网',
							icon: 'none'
						});
						return;
					}
					const isOn = e.detail.value;
					const onSwitch = isOn === true ? 1 : 0;
					const userId = this.userInfo.userId
					const sn = this.lightDevice.sn
					const res = await deviceApi.lampControl({
						userId,
						sn,
						onSwitch
					})
					if (res.code === 200) {
						this.lightStatus = {
							...this.lightStatus,
							open: isOn
						};
					} else {
						uni.showToast({
							title: '更改失败，请重试',
							icon: 'none'
						});
						this.lightOpen = !isOn;
					}
				} catch (e) {
					this.lightOpen = !e.detail.value;
				}

			},

			// 处理 WebSocket 推送的数据
			handleWsMessage(message) {
				const payload = message && message.data ? message.data : {};

				// 过滤设备断连类消息，存入消息队列
				if (payload.deviceOffline || payload.deviceOnline) {
					let msg = '';
					if (payload.deviceOffline) {
						msg = `${payload.deviceName || '设备'}已断开连接`;
					} else if (payload.deviceOnline) {
						msg = `${payload.deviceName || '设备'}已重新连接`;
					}
					// 消息入队
					this.messageQueue.push(msg);
					// 标记有未读消息
					this.hasUnreadMessage = true;
					this.getDeviceData();
				}
			},

			// 处理WebSocket错误消息
			handleWsErrorMsg(errorMsg) {
				const errText = errorMsg.msg || '设备状态更新失败';
				this.messageQueue.push(errText);
				this.hasUnreadMessage = true;
			},

			// 点击消息图标，逐个展示消息
			showNextMessage() {
				// 无未读消息时提示
				if (this.messageQueue.length === 0) {
					uni.showToast({
						title: '暂无新消息',
						icon: 'none'
					});
					this.hasUnreadMessage = false;
					return;
				}

				// 取出队列第一条消息展示
				const currentMsg = this.messageQueue.shift();
				uni.showModal({
					title: '设备通知',
					content: currentMsg,
					showCancel: false,
					// 弹窗关闭后，若还有消息则继续展示下一条
					complete: () => {
						if (this.messageQueue.length > 0) {
							this.showNextMessage();
						} else {
							// 队列空了，重置未读状态
							this.hasUnreadMessage = false;
						}
					}
				});
			},

			// 获取当前用户拥有的设备列表
			async getDeviceData() {
				try {
					const userInfo = uni.getStorageSync('userInfo') || {};
					if (userInfo.userId == null) {
						uni.showToast({
							title: "请先登录",
							icon: 'none',
							duration: 1000
						})
						setTimeout(() => {
							uni.switchTab({
								url: "/pages/home/home"
							})
						}, 1500);
						return;
					}
					const userId = userInfo.userId;
					const res = await deviceApi.ownerDevice({
						userId
					});

					if (res && res.code === 200 && Array.isArray(res.data)) {
						const list = res.data || [];
						this.deviceList = list;
						// 根据 category 区分不同设备（light / sensor）
						this.lightDevice = list.find(item => item.category === 'light') || null;
						this.sensorDevice = list.find(item => item.category === 'sensor') || null;

						// 已拿到设备后，继续请求各自的参数
						if (this.lightDevice) {
							await this.fetchLampParam();
						}
						if (this.sensorDevice) {
							await this.fetchSensorParam();
						}
					}
				} catch (err) {
					console.error('获取设备列表失败：', err);
					uni.showToast({
						title: '设备列表加载失败',
						icon: 'none'
					});
				}
			},

			// 调用智能灯参数接口 /device/lampParam
			async fetchLampParam() {
				try {
					const userInfo = uni.getStorageSync('userInfo') || {};
					const userId = userInfo.userId;
					if (!this.lightDevice || !userId) return;

					const sn = this.lightDevice.sn;
					if (!sn) return;

					const res = await deviceApi.lampParam({
						userId,
						sn
					});

					if (res && res.code === 200 && res.data) {
						this.lightStatus.online = res.data.connected === 1 ? true : false
						this.lightStatus.open = res.data.onSwitch === 1 ? true : false
						this.lightStatus.brightness = res.data.brightness
						this.lightOpen = res.data.onSwitch === 1 ? true : false
					}
				} catch (err) {
					console.error('获取智能灯参数失败：', err);
				}
			},

			// 调用温湿度感应器参数接口 /device/sensorParam
			async fetchSensorParam() {
				try {
					const userInfo = uni.getStorageSync('userInfo') || {};
					const userId = userInfo.userId;
					if (!this.sensorDevice || !userId) return;

					const sn = this.sensorDevice.sn;
					if (!sn) return;

					const res = await deviceApi.sensorParam({
						userId,
						sn
					});

					if (res && res.code === 200 && res.data) {
						this.sensorData.humidity = res.data.humidity
						this.sensorData.temperature = res.data.temperature
						this.sensorData.sensorConnected = res.data.connected === 1 ? true : false
					}
				} catch (err) {
					console.error('获取传感器参数失败：', err);
				}
			}
		}
	};
</script>

<style scoped>
	/* 整体页面 */
	.home-page {
		min-height: 100vh;
		box-sizing: border-box;
		padding: 80rpx 40rpx 40rpx;
		background-color: #f5f7fb;
	}

	/* 顶部欢迎区域改造：flex布局，右侧放消息图标 */
	.header {
		margin-bottom: 60rpx;
		display: flex;
		justify-content: space-between;
		align-items: center;
	}

	.welcome-area {
		flex: 1;
	}

	/* 消息图标样式 */
	.message-icon-wrapper {
		width: 60rpx;
		height: 60rpx;
		display: flex;
		justify-content: center;
		align-items: center;
	}

	.message-icon {
		width: 40rpx;
		height: 40rpx;
	}

	.welcome-text {
		font-size: 40rpx;
		font-weight: 600;
		color: #111827;
		margin-bottom: 16rpx;
	}

	.sub-text {
		font-size: 26rpx;
		color: #6b7280;
	}

	/* 区块标题 */
	.section-title {
		font-size: 30rpx;
		font-weight: 600;
		color: #111827;
		margin-bottom: 24rpx;
	}

	.device-list {
		display: flex;
		flex-wrap: wrap;
		gap: 24rpx;
	}

	/* 卡片基础样式 */
	.device-card {
		flex: 1 1 calc(50% - 12rpx);
		min-width: 300rpx;
		background-color: #ffffff;
		border-radius: 24rpx;
		padding: 24rpx 24rpx 28rpx;
		box-shadow: 0 12rpx 30rpx rgba(15, 23, 42, 0.06);
	}

	.card-top {
		display: flex;
		align-items: center;
		margin-bottom: 24rpx;
	}

	.avatar-wrapper {
		margin-right: 20rpx;
	}

	.avatar-circle {
		width: 96rpx;
		height: 96rpx;
		border-radius: 50%;
	}

	.avatar-image {
		width: 96rpx;
		height: 96rpx;
		border-radius: 50%;
	}

	.light-avatar {
		background: linear-gradient(135deg, #f97316, #fb7185);
	}

	.sensor-avatar {
		background: linear-gradient(135deg, #3b82f6, #22c55e);
	}

	.device-info {
		flex: 1;
	}

	.device-name-row {
		margin-bottom: 10rpx;
	}

	.device-name {
		font-size: 30rpx;
		font-weight: 600;
		color: #111827;
	}

	.device-status-row {
		display: flex;
		align-items: center;
	}

	.status-dot {
		width: 14rpx;
		height: 14rpx;
		border-radius: 50%;
		margin-right: 10rpx;
	}

	.status-online {
		background-color: #10b981;
	}

	.status-offline {
		background-color: #d1d5db;
	}

	.status-text {
		font-size: 24rpx;
		color: #6b7280;
	}

	/* 卡片底部 */
	.card-bottom {
		display: flex;
		justify-content: space-between;
		align-items: center;
	}

	.card-bottom-left {
		display: flex;
		align-items: center;
		gap: 16rpx;
	}

	.bottom-label {
		font-size: 26rpx;
		color: #4b5563;
	}

	.light-switch {
		transform: scale(0.9);
	}

	.card-bottom-right {
		font-size: 24rpx;
		color: #9ca3af;
	}

	/* 传感器卡片底部展示 */
	.sensor-bottom {
		flex-direction: column;
		align-items: flex-start;
		gap: 8rpx;
	}

	.sensor-main-value {
		margin-bottom: 4rpx;
	}

	.sensor-temperature {
		font-size: 40rpx;
		font-weight: 600;
		color: #111827;
	}

	.sensor-extra {
		font-size: 24rpx;
		color: #9ca3af;
	}

	.sensor-humidity {
		font-size: 24rpx;
	}

	/* 小屏时卡片全宽展示 */
	@media screen and (max-width: 750rpx) {
		.device-card {
			flex-basis: 100%;
		}
	}
</style>