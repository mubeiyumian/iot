<script>
	import {
		initWebSocket
	} from '@/common/utils/websocket.js';

	export default {
		onLaunch() {
			console.log('App Launch');
			// 如果本地已有 token，启动时自动尝试建立 WebSocket
			initWebSocket();
		},
		onShow() {
			console.log('App Show');
		},
		onHide() {
			console.log('App Hide');
		}
	}
</script>

<style>
	/*每个页面公共css */
</style>
