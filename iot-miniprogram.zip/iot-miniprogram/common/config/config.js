const env = process.env.NODE_ENV || 'development';

const config = {
	development: {
		baseURL: 'http://localhost:9000'
	},
	production: {
		baseURL: 'http://localhost:8080'
	}
};

export default config[env];