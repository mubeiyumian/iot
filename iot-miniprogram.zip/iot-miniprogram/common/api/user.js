import {
	request
} from '@/common/utils/request.js';

export const userApi = {
	//用户登录
	login: (data) => request({
		url: '/user/login',
		method: 'POST',
		header: {
			'Content-Type': 'application/json'
		},
		data
	}),
}