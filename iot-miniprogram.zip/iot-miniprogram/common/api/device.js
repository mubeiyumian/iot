import {
	request
} from '@/common/utils/request.js';

export const deviceApi = {
	// 获取用户拥有的设备列表
	ownerDevice: (data) =>
		request({
			url: '/device/ownerDevice',
			method: 'POST',
			header: {
				'Content-Type': 'application/json'
			},
			data
		}),

	// 智能灯参数接口
	lampParam: (data) =>
		request({
			url: '/device/lampParam',
			method: 'POST',
			header: {
				'Content-Type': 'application/json'
			},
			data
		}),

	// 温湿度感应器参数接口
	sensorParam: (data) =>
		request({
			url: '/device/sensorParam',
			method: 'POST',
			header: {
				'Content-Type': 'application/json'
			},
			data
		}),

	// 智能灯控制开关
	lampControl: (data) => 
		request({
			url: '/device/lampControl',
			method: 'POST',
			header: {
				'Content-Type': 'application/json'
			},
			data
		}),
};