import config from '@/common/config/config.js';

function buildFullUrl(baseURL, path) {
	if (!baseURL.startsWith('http')) {
		baseURL = 'http://' + baseURL;
	}
	const Base = baseURL.endsWith('/') ? baseURL : baseURL + '/';
	const Path = path.startsWith('/') ? path.slice(1) : path;
	return `${Base}${Path}`.replace(/([^:]\/)\/+/g, '$1');
}

uni.addInterceptor('request', {
	invoke(args) {
		// 跳过特定请求
		if (args.skipInterceptor) {
			return args;
		}
		const contentType = args.header['Content-Type'] || '';

		//处理请求
		if (contentType.includes('x-www-form-urlencoded') && args.data && typeof args.data === 'object') {
			args.data = Object.entries(args.data)
				.filter(([_, val]) => val !== undefined)
				.map(([key, val]) => `${encodeURIComponent(key)}=${encodeURIComponent(val)}`)
				.join('&');
		} else if (contentType.includes('application/json')) {
			// 常规 JSON 序列化
			args.data = typeof args.data === 'string' ? args.data : JSON.stringify(args.data);
		}
		if (args.method === 'GET' && args.data) {
			args.url += (args.url.includes('?') ? '&' : '?') + args.data;
			args.data = undefined;
		}
		args.url = buildFullUrl(config.baseURL, args.url);
		// 添加 token 到请求头
		const token = uni.getStorageSync('token');
		if (token) {
			args.header = args.header || {};
			args.header['token'] = `${token}`;
		}
		if (!args.hideLoading)
			uni.showLoading({
				title: '加载中'
			});
		return args;
	},
	success(res) {
		uni.hideLoading();
		const code = res.data.code;
		const msg = res.data.msg;
		// 如果 code 存在且不等于 200，弹窗显示 message
		if (code !== undefined && code !== 200) {
			uni.showToast({
				title: msg || '数据异常，请稍后重试', // 默认为 '操作失败
				icon: 'none',
				duration: 3000 // 弹窗显示时间，单位 ms
			});
		}
	},
	fail(err) {
		uni.hideLoading();
		uni.showToast({
			title: '网络异常',
			icon: 'none'
		});
	},
	complete(res) {
		// 关闭加载中提示
		uni.hideLoading();

		// 处理 HTTP 状态码异常
		if (res && res.statusCode) {
			const {
				statusCode
			} = res;
			if (statusCode !== undefined && statusCode === 401) {
				uni.switchTab({
					url: '/pages/home/home',
					success: () => {
						// 跳转成功后显示登录提示
						uni.showToast({
							title: '请先登录',
							icon: 'none',
							duration: 3000
						});
					}
				})
				// 直接返回
				return;
			}
			// 状态码不是 200，且不是 2xx 范围内的成功状态（200-299）
			if (statusCode !== 200 && !(statusCode >= 200 && statusCode < 300)) {
				uni.showToast({
					title: '数据异常，请稍后重试',
					icon: 'none',
					duration: 3000
				});
			}
		}
	}
});

// 通用请求方法
export const request = (options) => {
	return new Promise((resolve, reject) => {
		uni.request({
			...options,
			success: (res) => {
				resolve(res.data);
			},
			fail: (err) => {
				const error = new Error(err.errMsg || '网络请求失败');
				error.code = err.errno;
				reject(error);
			}
		});
	});
};