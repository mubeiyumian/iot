// WebSocket 管理工具
const WS_URL = 'ws://127.0.0.1:9002/ws/miniprogram';

let socketOpen = false;
let isConnecting = false;
let reconnectTimer = null;
let reconnectAttempts = 0;
const MAX_RECONNECT_ATTEMPTS = 5;
const RECONNECT_INTERVAL = 5000;

let hasInitListeners = false;

function initSocketEventHandlers() {
	if (hasInitListeners) return;
	hasInitListeners = true;

	uni.onSocketOpen(() => {
		socketOpen = true;
		isConnecting = false;
		reconnectAttempts = 0;
	});

	uni.onSocketError(() => {
		socketOpen = false;
		isConnecting = false;
		scheduleReconnect(true);
	});

	uni.onSocketClose(() => {
		socketOpen = false;
		isConnecting = false;
		scheduleReconnect(false);
	});

	uni.onSocketMessage((res) => {
		let message = res.data;
		console.log(res)
		try {
			if (typeof message === 'string') {
				message = JSON.parse(message);
			}
		} catch (e) {
			console.error('WebSocket 消息解析失败:', e, res.data);
			return;
		}

		if (!message || typeof message !== 'object') {
			return;
		}

		// 标准消息格式 { code: 200, data: {...}, timestamp: 17770000 }
		if (message.code === 200) {
			uni.$emit('ws-message', message);
		} else {
			uni.$emit('ws-message-error', message);
		}
	});
}

function scheduleReconnect(showToast) {
	if (reconnectAttempts >= MAX_RECONNECT_ATTEMPTS) {
		if (showToast) {
			uni.showToast({
				title: '网络连接已断开，请稍后重试',
				icon: 'none',
				duration: 3000
			});
		}
		return;
	}

	reconnectAttempts += 1;

	if (reconnectTimer) {
		clearTimeout(reconnectTimer);
		reconnectTimer = null;
	}

	const token = uni.getStorageSync('token');
	if (!token) {
		return;
	}

	reconnectTimer = setTimeout(() => {
		uni.showToast({
			title: '网络异常，正在重连',
			icon: 'none',
			duration: 2000
		});
		connectWithToken(token);
	}, RECONNECT_INTERVAL);
}

function connectWithToken(token) {
	if (!token) {
		console.warn('WebSocket 连接缺少 token');
		return;
	}

	if (socketOpen || isConnecting) {
		return;
	}

	isConnecting = true;
	initSocketEventHandlers();

	// 微信小程序对 WebSocket 的 header 支持有限，这里使用 query 参数携带 token，
	// 同时保留 header 以兼容 H5 / App 等其他端。
	const hasQuery = WS_URL.indexOf('?') !== -1;
	const urlWithToken = `${WS_URL}${hasQuery ? '&' : '?'}token=${encodeURIComponent(token)}`;

	uni.connectSocket({
		url: urlWithToken,
		header: {
			token
		},
		success() {},
		fail(err) {
			console.error('WebSocket 连接失败:', err);
			isConnecting = false;
			scheduleReconnect(true);
		}
	});
}

export function initWebSocket() {
	const token = uni.getStorageSync('token');
	if (!token) {
		return;
	}
	connectWithToken(token);
}

export function closeWebSocket() {
	if (reconnectTimer) {
		clearTimeout(reconnectTimer);
		reconnectTimer = null;
	}
	if (socketOpen || isConnecting) {
		uni.closeSocket();
	}
	socketOpen = false;
	isConnecting = false;
}

export function sendWebSocketMessage(payload) {
	if (!socketOpen) {
		uni.showToast({
			title: '连接未建立，请稍后重试',
			icon: 'none',
			duration: 2000
		});
		return;
	}

	let data = payload;
	if (typeof payload !== 'string') {
		try {
			data = JSON.stringify(payload);
		} catch (e) {
			console.error('WebSocket 发送数据序列化失败:', e, payload);
			return;
		}
	}

	uni.sendSocketMessage({
		data
	});
}

